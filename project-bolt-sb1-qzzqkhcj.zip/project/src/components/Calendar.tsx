import React from 'react';
import { DayPicker } from 'react-day-picker';
import { format } from 'date-fns';
import { Calendar as CalendarIcon } from 'lucide-react';
import { Meeting } from '../types';

interface CalendarProps {
  meetings: Meeting[];
  onDateSelect: (date: Date) => void;
}

export function Calendar({ meetings, onDateSelect }: CalendarProps) {
  const meetingDays = meetings.map(meeting => meeting.date);

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center gap-2 mb-6">
        <CalendarIcon className="w-5 h-5" style={{ color: '#7E003F' }} />
        <h2 className="text-lg font-semibold">Meeting Calendar</h2>
      </div>
      <DayPicker
        mode="single"
        selected={new Date()}
        onSelect={(date) => date && onDateSelect(date)}
        modifiers={{
          meeting: meetingDays
        }}
        modifiersStyles={{
          meeting: {
            fontWeight: 'bold'
          }
        }}
        className="custom-calendar"
      />
    </div>
  );
}