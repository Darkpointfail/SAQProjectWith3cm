import React from 'react';
import { ClipboardList } from 'lucide-react';
import { Meeting, SalesRep } from '../types';
import { format } from 'date-fns';

interface DailyRecapProps {
  meetings: Meeting[];
  salesReps: SalesRep[];
  selectedDate: Date;
}

export function DailyRecap({ meetings, salesReps, selectedDate }: DailyRecapProps) {
  const dailyMeetings = meetings.filter(
    meeting => format(meeting.date, 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd')
  );

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex items-center gap-2 mb-4">
        <ClipboardList className="w-5 h-5" style={{ color: '#7E003F' }} />
        <h2 className="text-lg font-semibold">Daily Recap</h2>
      </div>
      <div className="space-y-4">
        {dailyMeetings.length === 0 ? (
          <p className="text-gray-500">No meetings scheduled for {format(selectedDate, 'MMMM d, yyyy')}</p>
        ) : (
          dailyMeetings.map(meeting => {
            const salesRep = salesReps.find(rep => rep.id === meeting.salesRepId);
            return (
              <div key={meeting.id} className="border-l-4 border-[#7E003F] pl-4 py-2">
                <div className="flex items-center gap-3">
                  <img
                    src={salesRep?.image}
                    alt={salesRep?.name}
                    className="w-10 h-10 rounded-full"
                  />
                  <div>
                    <h3 className="font-medium">{meeting.title}</h3>
                    <p className="text-sm text-gray-600">
                      {format(meeting.date, 'h:mm a')} with {salesRep?.name}
                    </p>
                    {meeting.notes && (
                      <p className="text-sm text-gray-500 mt-1">{meeting.notes}</p>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}