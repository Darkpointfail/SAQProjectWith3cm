import React, { useState } from 'react';
import { Calendar } from '../components/Calendar';
import { DailyRecap } from '../components/DailyRecap';
import { Search } from '../components/Search';
import { meetings, salesReps, products } from '../data';
import { TrendingUp, Clock, Users, Building2 } from 'lucide-react';

function Dashboard() {
  const [selectedDate, setSelectedDate] = useState(new Date());

  const upcomingMeetings = meetings.filter(meeting => meeting.date > new Date()).length;
  const totalSalesReps = salesReps.length;
  const trendingProducts = products.filter(product => product.trending).length;

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <Clock className="w-8 h-8 text-[#7E003F]" />
            <div className="ml-4">
              <p className="text-sm text-gray-500">Upcoming Meetings</p>
              <p className="text-2xl font-semibold">{upcomingMeetings}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <Users className="w-8 h-8 text-[#7E003F]" />
            <div className="ml-4">
              <p className="text-sm text-gray-500">Sales Representatives</p>
              <p className="text-2xl font-semibold">{totalSalesReps}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <TrendingUp className="w-8 h-8 text-[#7E003F]" />
            <div className="ml-4">
              <p className="text-sm text-gray-500">Trending Products</p>
              <p className="text-2xl font-semibold">{trendingProducts}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Calendar meetings={meetings} onDateSelect={setSelectedDate} />
            <DailyRecap 
              meetings={meetings} 
              salesReps={salesReps} 
              selectedDate={selectedDate}
            />
          </div>
          <div className="bg-white rounded-lg shadow-md p-4">
            <h2 className="text-lg font-semibold mb-4">Trending Products</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {products
                .filter(product => product.trending)
                .map(product => (
                  <div key={product.id} className="border rounded-lg p-4">
                    <h3 className="font-medium">{product.name}</h3>
                    <p className="text-sm text-gray-600">{product.region}</p>
                    <p className="text-sm text-gray-500 mt-2">
                      {product.sales.toLocaleString()} bottles sold
                    </p>
                  </div>
                ))}
            </div>
          </div>
        </div>
        
        <div className="space-y-8">
          <Search salesReps={salesReps} products={products} />
          
          {/* Sales Representatives List */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-2 mb-6">
              <Building2 className="w-5 h-5" style={{ color: '#7E003F' }} />
              <h2 className="text-lg font-semibold">Sales Representatives</h2>
            </div>
            <div className="space-y-4">
              {salesReps.map(rep => (
                <div key={rep.id} className="flex items-start space-x-4 p-4 hover:bg-gray-50 rounded-lg transition-colors">
                  <img
                    src={rep.image}
                    alt={rep.name}
                    className="w-12 h-12 rounded-full"
                  />
                  <div>
                    <h3 className="font-medium">{rep.name}</h3>
                    <p className="text-sm text-gray-600">{rep.company}</p>
                    <div className="mt-1 flex flex-wrap gap-2">
                      {rep.portfolio.map((item, index) => (
                        <span
                          key={index}
                          className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-[#7E003F]/10 text-[#7E003F]"
                        >
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

export default Dashboard;