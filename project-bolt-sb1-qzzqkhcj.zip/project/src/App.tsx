import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import { Wine, Beaker, Target, Calendar as CalendarIcon, UserCircle } from 'lucide-react';
import Dashboard from './pages/Dashboard';
import Testing from './pages/Testing';
import PromoPunch from './pages/PromoPunch';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="flex items-center">
                <Wine className="w-8 h-8" style={{ color: '#7E003F' }} />
                <span className="ml-2 text-xl font-semibold text-gray-900">WineMeet Manager</span>
              </Link>
              
              <div className="hidden md:flex ml-10 space-x-8">
                <Link to="/testing" className="flex items-center text-gray-600 hover:text-[#7E003F] px-3 py-2 rounded-md text-sm font-medium">
                  <Beaker className="w-4 h-4 mr-2" />
                  My Testing
                </Link>
                <Link to="/promopunch" className="flex items-center text-gray-600 hover:text-[#7E003F] px-3 py-2 rounded-md text-sm font-medium">
                  <Target className="w-4 h-4 mr-2" />
                  PromoPunch
                </Link>
                <Link to="#" className="flex items-center text-gray-600 hover:text-[#7E003F] px-3 py-2 rounded-md text-sm font-medium">
                  <CalendarIcon className="w-4 h-4 mr-2" />
                  My Availabilities
                </Link>
              </div>
            </div>

            {/* Profile Section */}
            <div className="flex items-center">
              <button className="flex items-center space-x-3 text-gray-700 hover:text-[#7E003F] transition-colors">
                <span className="text-sm font-medium">Sophie Laurent</span>
                <div className="relative">
                  <img
                    src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200&h=200"
                    alt="Profile"
                    className="w-8 h-8 rounded-full border-2 border-transparent hover:border-[#7E003F]"
                  />
                  <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border-2 border-white rounded-full"></div>
                </div>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/testing" element={<Testing />} />
        <Route path="/promopunch" element={<PromoPunch />} />
      </Routes>
    </div>
  );
}

export default App;